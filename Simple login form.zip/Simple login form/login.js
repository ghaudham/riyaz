// login function

const login = document.querySelector('.login');
login.onclick = (e) => {
    e.preventDefault();
    // cautch the valu which is type user login page
    const emailAddress = document.getElementById("emailAddress").value;
    const passWord = document.getElementById("passWord").value;

    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
  
    // Search for a user with the specified email
    const foundUser = storedUsers.find(user => user.email === emailAddress);
  
    // If a matching user was found, display their information
    if (foundUser) {


    // let's get value in localstorage which store user in registration field
    const Email = foundUser.email;
    const firstName = foundUser.firstName;
    const lastName = foundUser.lastName;
    const Password = foundUser.password;
    const cpassword = foundUser.cpassword;
    const rolee = foundUser.role;

    if( emailAddress == "" && passWord == ""){
        Swal.fire(
            'Opps..!',
            'input field has no value!',
            'error'
        );
    }
    else
    {
        if(emailAddress == Email && passWord == Password){
            Swal.fire(
                `Welcome ${firstName}!!!`,
                'login successful!',
                'success'
            );
            setTimeout(()=>{
                window.location.href = "userhome.html";
                localStorage.setItem('loginuseremail', JSON.stringify(Email));
                localStorage.setItem('loginuserrole', JSON.stringify(rolee));
                localStorage.setItem('loginuserName', JSON.stringify(firstName));

            },2000)
        }else
        {
            Swal.fire(
                'Opps..!',
                'Something is wrong!',
                'error'
            );
        }
    };
    }else{
        console.log(`User with email ${emailAddress} not found`);
        Swal.fire(
            'Opps..!',
            `User with email ${emailAddress} is not found in database`,
            'error'
        );
    }

};

function findUserByEmail(email) {
    // Retrieve the array of users from localStorage
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
  
    // Search for a user with the specified email
    const foundUser = storedUsers.find(user => user.email === email);
  
    // If a matching user was found, display their information
    if (foundUser) {
      const firstName = foundUser.firstName;
      const lastName = foundUser.lastName;
      const password = foundUser.password;
      const cpassword = foundUser.cpassword;
      console.log(`Found user: ${firstName} ${lastName} (${email})`);
    } else {
      console.log(`User with email ${email} not found`);
    }
  }
  