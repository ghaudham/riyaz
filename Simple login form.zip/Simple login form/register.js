const submit_button = document.querySelector(".button");
submit_button.onclick = (e) => {
    e.preventDefault();
    const fname = document.getElementById("fname").value;
    const lname = document.getElementById("lname").value;
    const email = document.getElementById("email").value;
    const pass = document.getElementById("pass").value;
    const cpass = document.getElementById("cpass").value;
    const role = document.getElementById("urole").value;

    // localStorage.setItem('FirstName', fname);
    // localStorage.setItem('LastName', lname);
    // localStorage.setItem('Email', email);
    // localStorage.setItem('Password', pass);
    // localStorage.setItem('Cpassword', cpass);
    if(fname == "" && lname == "" && email == "" && pass == "" && cpass == ""){
        Swal.fire(
            'Opps..!',
            'input field has no value!',
            'error'
        );
    }
    else
    {
        if(pass.length >= 6 && pass.length <= 20)
    {
        if( pass !== cpass){
            Swal.fire(
                'Opps..!',
                'Password not matching!',
                'error'
            );
        }
        else
        {
            Swal.fire(
                'Good job!',
                'Register successful!',
                'success'
            );
            setTimeout(()=>{
                    location.href='LoginBox.html';
                    },5000)
        }
    }
    else
    {
        Swal.fire(
            'Opps..!',
            'Input mim six digit password!',
            'error'
        );
    }


    if(findUserByEmail(email) != true){
        addUser(fname,lname,email,pass,cpass,role);
    }else{
  
    Swal.fire(
        `${email} mail already added!!`,
        'Register failed!',
        'error'
    );
    }



    }


}


// Add a new user to the array of users stored in localStorage
function addUser(firstName, lastName, email, password, cpassword, role) {
    // Retrieve the array of users from localStorage
    let storedUsers = JSON.parse(localStorage.getItem('users')) || [];
  
    // Check if a user with the same email already exists
    const existingUser = storedUsers.find(user => user.email === email);
    if (existingUser) {
      console.log('A user with this email already exists');
      return;
    }
  
    // Create a new user object
    const newUser = {
      firstName,
      lastName,
      email,
      password,
      cpassword,
      role
    };
  
    // Add the new user to the array
    storedUsers.push(newUser);
  
    // Store the updated array of users in localStorage
    localStorage.setItem('users', JSON.stringify(storedUsers));
  
    alert('User added successfully');
    window.location.href = "login.html";
}
  
  // Find a user by email
  function findUserByEmail(email) {
    // Retrieve the array of users from localStorage
    const storedUsers = JSON.parse(localStorage.getItem('users')) || [];
  
    // Search for a user with the specified email
    const foundUser = storedUsers.find(user => user.email === email);
  
    // If a matching user was found, display their information
    if (foundUser) {
      const firstName = foundUser.firstName;
      const lastName = foundUser.lastName;
      const password = foundUser.password;
      const cpassword = foundUser.cpassword;
      console.log(`Found user: ${firstName} ${lastName} (${email})`);
      return true
    } else {
      console.log(`User with email ${email} not found`);
      return false
    }
  }
  
  // Example usage: add a new user
  //addUser('John', 'Doe', 'johndoe@example.com', 'password1', 'password1');
  
  // Example usage: find a user by email
  //findUserByEmail('johndoe@example.com');
  



  